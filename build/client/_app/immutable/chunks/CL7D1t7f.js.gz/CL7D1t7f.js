import{D as a}from"./_SuVmlR5.js";a();
