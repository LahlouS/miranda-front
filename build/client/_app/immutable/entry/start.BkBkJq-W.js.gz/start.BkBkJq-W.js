import{d as a}from"../chunks/Cna-DAt6.js";export{a as start};
