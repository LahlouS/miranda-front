import{d as a}from"../chunks/c86IGuWO.js";export{a as start};
