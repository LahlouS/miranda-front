import{d as a}from"../chunks/CHaFX-VK.js";export{a as start};
