import{d as a}from"../chunks/6CztJwP1.js";export{a as start};
