import{D as a}from"./g3Tmz0S3.js";a();
